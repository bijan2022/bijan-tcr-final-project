from django.db import models
from django.contrib.auth.models import User
from datetime import datetime,timedelta



class lenderExtra(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    money = models.CharField(max_length=40)
    currency = models.CharField(max_length=40)
    #used in issue deposit
    def __str__(self):
        return self.user.first_name+'['+str(self.money)+']'
    @property
    def get_name(self):
        return self.user.first_name
    @property
    def getuserid(self):
        return self.user.id


class deposit(models.Model):
    catchoice= [
        ('dollar', 'dollar'),
        ('dirham', 'dirham'),
        ('euro', 'euro'),
        ('USD', 'USD'),
        ('yen', 'yen'),
        ]
    name=models.CharField(max_length=30)
    lenderage=models.PositiveIntegerField()
    bankname=models.CharField(max_length=40)
    category=models.CharField(max_length=30,choices=catchoice,default='dollar')
    def __str__(self):
        return str(self.name)+"["+str(self.lenderage)+']'


def get_expiry():
    return datetime.today() + timedelta(days=15)
class Issueddeposit(models.Model):
    #moved this in forms.py
    #money=[(lender.money,str(lender.get_name)+' ['+str(lender.money)+']') for lender in lenderExtra.objects.all()]
    money=models.CharField(max_length=30)
    #lenderage=[(str(deposit.lenderage),deposit.name+' ['+str(deposit.lenderage)+']') for deposit in deposit.objects.all()]
    lenderage=models.CharField(max_length=30)
    issuedate=models.DateField(auto_now=True)
    expirydate=models.DateField(default=get_expiry)
    def __str__(self):
        return self.money
