from django.shortcuts import render
from django.http import HttpResponseRedirect
from . import forms,models
from django.http import HttpResponseRedirect
from django.contrib.auth.models import Group
from django.contrib import auth
from django.contrib.auth.decorators import login_required,user_passes_test
from datetime import datetime,timedelta,date
from django.core.mail import send_mail
from bankitmanagement.settings import EMAIL_HOST_USER


def home_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request,'bankit/index.html')

#for showing signup/login button for lender
def lenderclick_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request,'bankit/lenderclick.html')

#for showing signup/login button for teacher
def adminclick_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request,'bankit/adminclick.html')



def adminsignup_view(request):
    form=forms.AdminSigupForm()
    if request.method=='POST':
        form=forms.AdminSigupForm(request.POST)
        if form.is_valid():
            user=form.save()
            user.set_password(user.password)
            user.save()


            my_admin_group = Group.objects.get_or_create(name='ADMIN')
            my_admin_group[0].user_set.add(user)

            return HttpResponseRedirect('adminlogin')
    return render(request,'bankit/adminsignup.html',{'form':form})






def lendersignup_view(request):
    form1=forms.lenderUserForm()
    form2=forms.lenderExtraForm()
    mydict={'form1':form1,'form2':form2}
    if request.method=='POST':
        form1=forms.lenderUserForm(request.POST)
        form2=forms.lenderExtraForm(request.POST)
        if form1.is_valid() and form2.is_valid():
            user=form1.save()
            user.set_password(user.password)
            user.save()
            f2=form2.save(commit=False)
            f2.user=user
            user2=f2.save()

            my_lender_group = Group.objects.get_or_create(name='lender')
            my_lender_group[0].user_set.add(user)

        return HttpResponseRedirect('lenderlogin')
    return render(request,'bankit/lendersignup.html',context=mydict)




def is_admin(user):
    return user.groups.filter(name='ADMIN').exists()

def afterlogin_view(request):
    if is_admin(request.user):
        return render(request,'bankit/adminafterlogin.html')
    else:
        return render(request,'bankit/lenderafterlogin.html')


@login_required(login_url='adminlogin')
@user_passes_test(is_admin)
def adddeposit_view(request):
    #now it is empty deposit form for sending to html
    form=forms.depositForm()
    if request.method=='POST':
        #now this form have data from html
        form=forms.depositForm(request.POST)
        if form.is_valid():
            user=form.save()
            return render(request,'bankit/depositadded.html')
    return render(request,'bankit/adddeposit.html',{'form':form})

@login_required(login_url='adminlogin')
@user_passes_test(is_admin)
def viewdeposit_view(request):
    deposits=models.deposit.objects.all()
    return render(request,'bankit/viewdeposit.html',{'deposits':deposits})




@login_required(login_url='adminlogin')
@user_passes_test(is_admin)
def issuedeposit_view(request):
    form=forms.IssueddepositForm()
    if request.method=='POST':
        #now this form have data from html
        form=forms.IssueddepositForm(request.POST)
        if form.is_valid():
            obj=models.Issueddeposit()
            obj.money=request.POST.get('money2')
            obj.lenderage=request.POST.get('lenderage2')
            obj.save()
            return render(request,'bankit/depositissued.html')
    return render(request,'bankit/issuedeposit.html',{'form':form})


@login_required(login_url='adminlogin')
@user_passes_test(is_admin)
def viewissueddeposit_view(request):
    issueddeposits=models.Issueddeposit.objects.all()
    li=[]
    for ib in issueddeposits:
        issdate=str(ib.issuedate.day)+'-'+str(ib.issuedate.month)+'-'+str(ib.issuedate.year)
        expdate=str(ib.expirydate.day)+'-'+str(ib.expirydate.month)+'-'+str(ib.expirydate.year)
        #fine calculation
        days=(date.today()-ib.issuedate)
        print(date.today())
        d=days.days
        fine=0
        if d>15:
            day=d-15
            fine=day*10


        deposits=list(models.deposit.objects.filter(lenderage=ib.lenderage))
        lenders=list(models.lenderExtra.objects.filter(money=ib.money))
        i=0
        for l in deposits:
            t=(lenders[i].get_name,lenders[i].money,deposits[i].name,deposits[i].bankname,issdate,expdate,fine)
            i=i+1
            li.append(t)

    return render(request,'bankit/viewissueddeposit.html',{'li':li})

@login_required(login_url='adminlogin')
@user_passes_test(is_admin)
def viewlender_view(request):
    lenders=models.lenderExtra.objects.all()
    return render(request,'bankit/viewlender.html',{'lenders':lenders})


@login_required(login_url='lenderlogin')
def viewissueddepositbylender(request):
    lender=models.lenderExtra.objects.filter(user_id=request.user.id)
    issueddeposit=models.Issueddeposit.objects.filter(money=lender[0].money)

    li1=[]

    li2=[]
    for ib in issueddeposit:
        deposits=models.deposit.objects.filter(lenderage=ib.lenderage)
        for deposit in deposits:
            t=(request.user,lender[0].money,lender[0].currency,deposit.name,deposit.bankname)
            li1.append(t)
        issdate=str(ib.issuedate.day)+'-'+str(ib.issuedate.month)+'-'+str(ib.issuedate.year)
        expdate=str(ib.expirydate.day)+'-'+str(ib.expirydate.month)+'-'+str(ib.expirydate.year)
        #fine calculation
        days=(date.today()-ib.issuedate)
        print(date.today())
        d=days.days
        fine=0
        if d>15:
            day=d-15
            fine=day*10
        t=(issdate,expdate,fine)
        li2.append(t)

    return render(request,'bankit/viewissueddepositbylender.html',{'li1':li1,'li2':li2})

def aboutus_view(request):
    return render(request,'bankit/aboutus.html')


