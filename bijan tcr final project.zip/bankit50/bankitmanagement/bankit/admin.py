from django.contrib import admin
from .models import deposit,lenderExtra,Issueddeposit
# Register your models here.
class depositAdmin(admin.ModelAdmin):
    pass
admin.site.register(deposit, depositAdmin)


class lenderExtraAdmin(admin.ModelAdmin):
    pass
admin.site.register(lenderExtra, lenderExtraAdmin)


class IssueddepositAdmin(admin.ModelAdmin):
    pass
admin.site.register(Issueddeposit, IssueddepositAdmin)
